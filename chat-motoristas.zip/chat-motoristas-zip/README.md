# 🚗 Chat Motoristas — Sistema de Comunicação em Tempo Real

Sistema de chat tipo WhatsApp para comunicação entre motoristas e time de suporte.

---

## 🚀 Como rodar localmente

### 1. Instalar dependências
```bash
cd chat-motoristas
npm install
```

### 2. Iniciar o servidor
```bash
npm start
```

O servidor sobe em **http://localhost:3000**

---

## 🔗 URLs do sistema

| Página | URL |
|--------|-----|
| Painel do Suporte | `http://localhost:3000/suporte` |
| Chat do Motorista | `http://localhost:3000/driver/TOKEN_DO_MOTORISTA` |

---

## 🔑 Acessos padrão

**Senha do painel de suporte:** `suporte123`

Para mudar a senha, defina a variável de ambiente:
```
SUPPORT_PASSWORD=minha_senha_segura
```

---

## 📱 Fluxo de uso

### Time de Suporte:
1. Acesse `/suporte`
2. Digite a senha de acesso
3. Clique em **"+ Novo motorista"** para cadastrar
4. Preencha nome, CPF e placa
5. Copie o link gerado e envie para o motorista (WhatsApp, SMS, e-mail)
6. Responda mensagens em tempo real pelo painel

### Motorista:
1. Clica no link recebido
2. Digita seu nome e CPF para verificação
3. Começa a conversar com o suporte

---

## ☁️ Deploy no Railway (gratuito)

### Passo a passo:

1. **Crie uma conta** em https://railway.app

2. **Instale o Railway CLI:**
   ```bash
   npm install -g @railway/cli
   ```

3. **Faça login:**
   ```bash
   railway login
   ```

4. **Inicie o projeto (dentro da pasta chat-motoristas):**
   ```bash
   railway init
   railway up
   ```

5. **Gere um domínio público:**
   - No painel Railway → Settings → Networking → Generate Domain

6. **Configure a senha do suporte (opcional):**
   - Railway → Variables → Add Variable
   - Nome: `SUPPORT_PASSWORD`
   - Valor: `sua_senha_aqui`

---

## 🛠 Variáveis de ambiente

| Variável | Padrão | Descrição |
|----------|--------|-----------|
| `PORT` | `3000` | Porta do servidor |
| `SUPPORT_PASSWORD` | `suporte123` | Senha do painel de suporte |
| `DB_PATH` | `./data/chat.db` | Caminho do banco de dados |

---

## 📦 Tecnologias usadas

- **Node.js + Express** — servidor HTTP
- **Socket.io** — mensagens em tempo real (WebSocket)
- **SQLite (better-sqlite3)** — banco de dados local, zero configuração
- **HTML/CSS/JS puro** — frontend sem frameworks

---

## 📁 Estrutura do projeto

```
chat-motoristas/
├── server/
│   ├── index.js       ← servidor principal
│   └── database.js    ← banco de dados SQLite
├── public/
│   ├── driver.html    ← página do motorista
│   ├── support.html   ← painel do time
│   └── index.html     ← redirect
├── data/              ← banco criado automaticamente
├── package.json
├── railway.toml
└── README.md
```
