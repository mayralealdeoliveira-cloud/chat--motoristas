const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const db = require('./database');

db.init().then(() => {

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

app.get('/driver/:token', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/driver.html'));
});
app.get('/suporte', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/support.html'));
});

app.post('/api/driver/login', (req, res) => {
  const { token, nome, cpf } = req.body;
  if (!token || !nome || !cpf) return res.status(400).json({ error: 'Dados incompletos' });
  const driver = db.prepare('SELECT * FROM drivers WHERE token = ?').get(token);
  if (!driver) return res.status(404).json({ error: 'Link inválido ou expirado' });
  const cpfLimpo = cpf.replace(/\D/g, '');
  if (driver.cpf !== cpfLimpo) return res.status(401).json({ error: 'CPF não confere com este link' });
  db.prepare('UPDATE drivers SET nome = ?, online = 1, last_seen = ? WHERE token = ?')
    .run(nome.trim(), new Date().toISOString(), token);
  const msgs = db.prepare('SELECT * FROM messages WHERE driver_id = ? ORDER BY created_at ASC').all(driver.id);
  res.json({ success: true, driver: { id: driver.id, nome: nome.trim(), token }, messages: msgs });
});

app.post('/api/support/login', (req, res) => {
  const { senha } = req.body;
  const SUPPORT_PASSWORD = process.env.SUPPORT_PASSWORD || 'suporte123';
  if (senha !== SUPPORT_PASSWORD) return res.status(401).json({ error: 'Senha incorreta' });
  res.json({ success: true });
});

app.get('/api/support/drivers', (req, res) => {
  const drivers = db.prepare('SELECT * FROM drivers ORDER BY last_seen DESC').all();
  const result = drivers.map(d => {
    const unread = db.prepare("SELECT COUNT(*) as c FROM messages WHERE driver_id = ? AND lida = 0 AND sender = 'driver'").get(d.id);
    const lastMsg = db.prepare('SELECT content, created_at FROM messages WHERE driver_id = ? ORDER BY created_at DESC LIMIT 1').get(d.id);
    return { ...d, nao_lidas: unread ? unread.c : 0, ultima_msg: lastMsg ? lastMsg.content : null, ultima_msg_at: lastMsg ? lastMsg.created_at : null };
  });
  res.json(result);
});

app.get('/api/support/messages/:driverId', (req, res) => {
  const msgs = db.prepare('SELECT * FROM messages WHERE driver_id = ? ORDER BY created_at ASC').all(req.params.driverId);
  db.prepare("UPDATE messages SET lida = 1 WHERE driver_id = ? AND sender = 'driver'").run(req.params.driverId);
  res.json(msgs);
});

app.post('/api/support/drivers', (req, res) => {
  const { nome, cpf, placa } = req.body;
  if (!nome || !cpf || !placa) return res.status(400).json({ error: 'Dados incompletos' });
  const cpfLimpo = cpf.replace(/\D/g, '');
  const token = uuidv4().replace(/-/g, '').substring(0, 12);
  const id = uuidv4();
  try {
    db.prepare('INSERT INTO drivers (id, nome, cpf, placa, token) VALUES (?, ?, ?, ?, ?)').run(id, nome.trim(), cpfLimpo, placa.trim().toUpperCase(), token);
    const driver = db.prepare('SELECT * FROM drivers WHERE id = ?').get(id);
    res.json({ success: true, driver, link: `/driver/${token}` });
  } catch (e) {
    res.status(400).json({ error: 'CPF ou placa já cadastrados' });
  }
});

const connectedSupport = new Set();
const connectedDrivers = new Map();

io.on('connection', (socket) => {
  socket.on('support:join', () => {
    socket.join('support-room');
    connectedSupport.add(socket.id);
    socket.emit('support:joined');
  });

  socket.on('driver:join', ({ driverId, token }) => {
    const driver = db.prepare('SELECT * FROM drivers WHERE id = ? AND token = ?').get(driverId, token);
    if (!driver) return socket.emit('error', 'Acesso negado');
    socket.join('driver-' + driverId);
    connectedDrivers.set(driverId, socket.id);
    db.prepare('UPDATE drivers SET online = 1, last_seen = ? WHERE id = ?').run(new Date().toISOString(), driverId);
    io.to('support-room').emit('driver:status', { driverId, online: true, nome: driver.nome });
    socket.emit('driver:joined', { driverId });
  });

  socket.on('driver:message', ({ driverId, token, content }) => {
    const driver = db.prepare('SELECT * FROM drivers WHERE id = ? AND token = ?').get(driverId, token);
    if (!driver || !content.trim()) return;
    const msgId = uuidv4();
    const now = new Date().toISOString();
    db.prepare('INSERT INTO messages (id, driver_id, sender, content, created_at, lida) VALUES (?, ?, ?, ?, ?, ?)').run(msgId, driverId, 'driver', content.trim(), now, 0);
    const msg = { id: msgId, driver_id: driverId, sender: 'driver', content: content.trim(), created_at: now, lida: 0 };
    socket.emit('message:sent', msg);
    io.to('support-room').emit('driver:new-message', { ...msg, driver_nome: driver.nome, placa: driver.placa });
  });

  socket.on('support:message', ({ driverId, content }) => {
    if (!content.trim()) return;
    const driver = db.prepare('SELECT * FROM drivers WHERE id = ?').get(driverId);
    if (!driver) return;
    const msgId = uuidv4();
    const now = new Date().toISOString();
    db.prepare('INSERT INTO messages (id, driver_id, sender, content, created_at, lida) VALUES (?, ?, ?, ?, ?, ?)').run(msgId, driverId, 'support', content.trim(), now, 1);
    const msg = { id: msgId, driver_id: driverId, sender: 'support', content: content.trim(), created_at: now };
    socket.emit('message:sent', msg);
    io.to('driver-' + driverId).emit('message:received', msg);
    io.to('support-room').emit('support:message-echo', msg);
  });

  socket.on('support:mark-read', ({ driverId }) => {
    db.prepare("UPDATE messages SET lida = 1 WHERE driver_id = ? AND sender = 'driver'").run(driverId);
    io.to('support-room').emit('support:messages-read', { driverId });
  });

  socket.on('disconnect', () => {
    connectedSupport.delete(socket.id);
    for (const [driverId, socketId] of connectedDrivers.entries()) {
      if (socketId === socket.id) {
        connectedDrivers.delete(driverId);
        db.prepare('UPDATE drivers SET online = 0, last_seen = ? WHERE id = ?').run(new Date().toISOString(), driverId);
        io.to('support-room').emit('driver:status', { driverId, online: false });
        break;
      }
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log('✅ Servidor em http://localhost:' + PORT);
  console.log('🔑 Senha suporte: ' + (process.env.SUPPORT_PASSWORD || 'suporte123'));
});

}); // end db.init
