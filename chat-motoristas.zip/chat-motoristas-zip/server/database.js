const initSqlJs = require('sql.js');
const path = require('path');
const fs = require('fs');

const dbPath = process.env.DB_PATH || path.join(__dirname, '../data/chat.db');
const dir = path.dirname(dbPath);
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

let _db = null;

// Salva o banco em disco periodicamente
function saveToDisk() {
  if (!_db) return;
  const data = _db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

async function initDB() {
  const SQL = await initSqlJs();
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    _db = new SQL.Database(fileBuffer);
  } else {
    _db = new SQL.Database();
  }

  _db.run(`
    CREATE TABLE IF NOT EXISTS drivers (
      id TEXT PRIMARY KEY,
      nome TEXT NOT NULL,
      cpf TEXT NOT NULL UNIQUE,
      placa TEXT NOT NULL UNIQUE,
      token TEXT NOT NULL UNIQUE,
      online INTEGER DEFAULT 0,
      last_seen TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      driver_id TEXT NOT NULL,
      sender TEXT NOT NULL,
      content TEXT NOT NULL,
      lida INTEGER DEFAULT 0,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_messages_driver ON messages(driver_id);
  `);

  saveToDisk();
  // Auto-save a cada 10 segundos
  setInterval(saveToDisk, 10000);
  console.log('📦 Banco de dados SQLite iniciado:', dbPath);
  return _db;
}

// Interface compatível com better-sqlite3
const db = {
  prepare(sql) {
    return {
      get(...params) {
        if (!_db) return null;
        const stmt = _db.prepare(sql);
        const result = stmt.getAsObject(params.flat());
        stmt.free();
        return Object.keys(result).length === 0 ? null : result;
      },
      all(...params) {
        if (!_db) return [];
        const stmt = _db.prepare(sql);
        stmt.bind(params.flat());
        const rows = [];
        while (stmt.step()) rows.push(stmt.getAsObject());
        stmt.free();
        return rows;
      },
      run(...params) {
        if (!_db) return;
        _db.run(sql, params.flat());
        saveToDisk();
      }
    };
  },
  exec(sql) {
    if (_db) { _db.run(sql); saveToDisk(); }
  },
  init: initDB
};

module.exports = db;
